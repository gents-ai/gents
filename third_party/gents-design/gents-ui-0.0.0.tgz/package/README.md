# @gents/ui

The Gents app UI kit: shadcn-style components on Base UI primitives, the agent
conversation patterns, and one CSS entry that wires them to `@gents/tokens`.

The kit is specified by tokens, color roles and anatomy, not by the library
underneath. Everything is styled through the roles in `@gents/tokens`, so a
consumer never sets a color by hand.

## Requirements

| Needs                 | Why                                      |
| --------------------- | ---------------------------------------- |
| React 19              | peer dependency                          |
| Vite (or any bundler) | the package ships ES modules + types     |
| Tailwind CSS v4       | the components are styled with utilities |

Tailwind is the only real setup cost. If the app has no Tailwind yet, add
`tailwindcss` and `@tailwindcss/vite`, register the plugin, and follow the CSS
step below. Tailwind's preflight will land on top of any existing base styles,
so check them once.

## Install

The package is not on a public registry. Two ways in:

**Tarball** (matches an npm-workspaces repo):

```sh
# in this repo
pnpm --filter @gents/tokens pack --pack-destination ../../out
pnpm --filter @gents/ui pack --pack-destination ../../out
# in the consuming app
npm install ../path/to/out/gents-tokens-0.0.0.tgz ../path/to/out/gents-ui-0.0.0.tgz
```

`prepack` builds `dist` first with `vp pack`. The published `package.json` points every export
at `dist`, so nothing in the consumer compiles TSX.

**Private registry** (GitHub Packages): `publishConfig.access` is `restricted`,
so `pnpm publish` can only ever go to a private scope. Add a `registry` under
`publishConfig` when you set one up.

## CSS

One import after Tailwind itself:

```css
@import 'tailwindcss';
@import '@gents/ui/styles.css';
```

`styles.css` brings in the tokens and the Tailwind theme, `tw-animate-css`, the
shadcn helper layer, and an `@source` so utilities used inside the kit are
generated. Do not import `@gents/tokens` separately.

Fonts come with it. The tokens import Inter, Lora and Geist Mono from
fontsource, so the app expression needs nothing more. Nyght Serif, the
marketing display face, is the one exception; a marketing site self-hosts it
(see `apps/brand-guide/src/index.css`), and without it display type falls back
to Lora.

## Root attributes

Two attributes on `<html>` select the expression and the theme:

```html
<html data-context="app" data-theme="dark"></html>
```

- `data-context="app"` switches the grounds, radii and roles to the app
  expression. Without it you get the marketing expression, which is wrong for
  product UI.
- `data-theme="dark"` flips a subtree to dark. Omit it for light. A nested
  `data-theme="light"` re-lights a region inside a dark one.

Read the OS preference and set the attribute yourself, for example from
Tauri's window theme API or `matchMedia`.

## Import

```tsx
import { Button } from '@gents/ui/components/button'
import { Card, CardHeader, CardTitle, CardContent } from '@gents/ui/components/card'
import {
  Composer,
  UserMessage,
  AssistantMessage,
  ToolSteps,
  ToolStep,
} from '@gents/ui/conversation'
import { cn } from '@gents/ui/lib/utils'
```

One path per component, matching the file names in `src/components`. There is
no barrel, so you only bundle what you import.

## Popups and portals

Dialog, menu, select, tooltip, popover, sheet and friends render through a
portal. By default they portal to `document.body`, which is fine when the whole
document carries `data-context` and `data-theme`. If you theme only a region,
wrap it in `PortalContainerProvider` from `@gents/ui/lib/portal-container` and
pass the region's element, so popups inherit its theme.

## Conversation patterns

`@gents/ui/conversation` is the agent chat panel: `PanelHeader`, `UserMessage`,
`AssistantMessage`, `ToolSteps` and `ToolStep`, and `Composer`. They are
controlled components; the app owns the transcript and the state.

```tsx
<PanelHeader title="Gents Conductor" onNew={startNew} onClose={close} />

<UserMessage actions onEdit={edit} onCopy={copy}>
  Add a dark mode toggle to the scope.
</UserMessage>

<AssistantMessage actions onRetry={retry} onCopy={copy}>
  {/* your markdown renderer's output; prose-app styles it */}
</AssistantMessage>

<ToolSteps title="Activity">
  <ToolStep label="Run type check" status="running" />
  <ToolStep label="Delegate to Reviewer" status="pending" />
</ToolSteps>

<Composer
  value={draft}
  onChange={setDraft}
  onSend={send}
  models={['Fable', 'Opus']}
  model={model}
  onModelChange={setModel}
  sending={busy}
/>
```

Leave `models` out and the composer has no model menu, for a session whose
behavior is already fixed; pass `leading` to put your own control there,
such as a behavior picker. The attach and dictate buttons appear only when
`onAttach` and `onDictate` are given. While `sending`, pass `onStop` and the
send slot becomes a Stop button for interrupting the run. `above` renders
inside the frame over the textarea, for a suggestion menu, and `onKeyDown`
runs before the composer's own keys; call `preventDefault` to claim one.

Markdown rendering stays out of the kit. Put the output of react-markdown or
any other renderer inside `AssistantMessage`; the `prose-app` utility styles
headings, code, lists, tables and links, and its spacing only flows forward so
streamed content never shifts what is already on screen.

No component paints a text marker on its own. The tokens ship `highlight`,
`highlight-purple` and `highlight-yellow` utilities for a run of a secondary
brand color behind inline text; applying one is a deliberate choice in the
app, not something the kit does for you.

## WebKit

Tauri on macOS renders with WebKit. Two features the kit uses are newer there:
`field-sizing: content` on the composer textarea and `box-decoration-break` on
highlight markers. Both degrade to a fixed-height textarea and a plainer
marker. Check them in Safari first.

## Samples

`apps/app` in this repo is a complete consumer: the CSS entry, the root
attributes set from the OS, and a controlled agent screen built from the kit.
`apps/website` shows the other case: a marketing page in the display
expression that depends on `@gents/tokens` alone. A site in that voice needs
the palette, type and marketing utilities, not the component kit. If a page
ever embeds live product UI, it gets a bounded `data-context="app"` region
and imports the kit like an app would.

## Adding components

From `apps/brand-guide` in this repo:

```sh
pnpm dlx shadcn@latest add <name>
```

The guide's `components.json` aliases `ui` to `@gents/ui/components`, so new
files land in `packages/ui/src/components` and pick up the tokens through
`ui.css`. Document the component in the brand guide in the same change.

/**
 * Design tokens as JS values, for when a token is needed outside CSS
 * (e.g. canvas, charts, exporting to Figma). Mirrors the core brand
 * colors in tokens.css.
 */
export const tokens = {
  color: {
    white: '#ffffff',
    green: '#283f2d', // primary
    gray: '#e1e1e1', // secondary
    purple: '#ddcbff',
    yellow: '#f3f4a9',
    lime: '#cdffcb',
  },
} as const

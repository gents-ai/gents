import {
  createContext,
  useContext,
  useMemo,
  useState,
  type AnchorHTMLAttributes,
  type MouseEvent,
  type ReactNode,
} from 'react'
import type { Route } from './nav'

export type Nav = {
  route: Route
  canBack: boolean
  canForward: boolean
  navigate: (route: Route) => void
  back: () => void
  forward: () => void
  href: (route: Route) => string
}

const NavContext = createContext<Nav | null>(null)

export function NavProvider({ value, children }: { value: Nav; children: ReactNode }) {
  return <NavContext.Provider value={value}>{children}</NavContext.Provider>
}

export function useNav(): Nav {
  const nav = useContext(NavContext)
  if (!nav) throw new Error('useNav must be used inside NavProvider')
  return nav
}

export function MemoryNavProvider({
  initial = { name: 'sessions' },
  children,
}: {
  initial?: Route
  children: ReactNode
}) {
  /* the cursor and its list, as one value so a move and its entries agree */
  const [history, setHistory] = useState<{ entries: Route[]; index: number }>({
    entries: [initial],
    index: 0,
  })
  const value = useMemo<Nav>(
    () => ({
      route: history.entries[history.index]!,
      canBack: history.index > 0,
      canForward: history.index < history.entries.length - 1,
      href: () => '#',
      navigate: (route) =>
        setHistory((h) => {
          const entries = [...h.entries.slice(0, h.index + 1), route]
          return { entries, index: entries.length - 1 }
        }),
      back: () => setHistory((h) => (h.index > 0 ? { ...h, index: h.index - 1 } : h)),
      forward: () =>
        setHistory((h) => (h.index < h.entries.length - 1 ? { ...h, index: h.index + 1 } : h)),
    }),
    [history],
  )
  return <NavProvider value={value}>{children}</NavProvider>
}

export function Link({
  to,
  onClick,
  ...props
}: { to: Route } & AnchorHTMLAttributes<HTMLAnchorElement>) {
  const nav = useNav()
  const handle = (e: MouseEvent<HTMLAnchorElement>) => {
    onClick?.(e)
    if (e.defaultPrevented) return
    if (e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return
    e.preventDefault()
    nav.navigate(to)
  }
  return <a href={nav.href(to)} onClick={handle} {...props} />
}

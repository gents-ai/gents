import {
  createContext,
  useContext,
  useMemo,
  useState,
  type AnchorHTMLAttributes,
  type MouseEvent,
  type ReactNode,
} from 'react'
import type { Route } from './nav'

export type Nav = {
  route: Route
  navigate: (route: Route) => void
  back: () => void
  href: (route: Route) => string
}

const NavContext = createContext<Nav | null>(null)

export function NavProvider({ value, children }: { value: Nav; children: ReactNode }) {
  return <NavContext.Provider value={value}>{children}</NavContext.Provider>
}

export function useNav(): Nav {
  const nav = useContext(NavContext)
  if (!nav) throw new Error('useNav must be used inside NavProvider')
  return nav
}

export function MemoryNavProvider({
  initial = { name: 'sessions' },
  children,
}: {
  initial?: Route
  children: ReactNode
}) {
  const [stack, setStack] = useState<Route[]>([initial])
  const value = useMemo<Nav>(
    () => ({
      route: stack[stack.length - 1]!,
      href: () => '#',
      navigate: (route) => setStack((s) => [...s, route]),
      back: () => setStack((s) => (s.length > 1 ? s.slice(0, -1) : s)),
    }),
    [stack],
  )
  return <NavProvider value={value}>{children}</NavProvider>
}

export function Link({
  to,
  onClick,
  ...props
}: { to: Route } & AnchorHTMLAttributes<HTMLAnchorElement>) {
  const nav = useNav()
  const handle = (e: MouseEvent<HTMLAnchorElement>) => {
    onClick?.(e)
    if (e.defaultPrevented) return
    if (e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return
    e.preventDefault()
    nav.navigate(to)
  }
  return <a href={nav.href(to)} onClick={handle} {...props} />
}

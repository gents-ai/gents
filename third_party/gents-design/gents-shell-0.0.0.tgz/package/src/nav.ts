/* A route may name the node it is about. Without one, the shell's selected
   node is implied, as it always was; with one, a link survives a change of
   selection or scope. `nodeDid` is the deployment's identity; core is
   renaming its field from agent_did to node_did (gents #1799), and this is
   the one place the shell spells it. */
export type Route =
  | { name: 'sessions'; nodeDid?: string }
  | { name: 'session'; sessionId: string | null; nodeDid?: string }
  | { name: 'mailbox'; nodeDid?: string }
  | { name: 'nodes' }
  | { name: 'agents' }
  | { name: 'agent'; nodeDid: string; section: string; item?: string }

const scoped = (nodeDid: string | undefined, path: string) =>
  nodeDid ? `/nodes/${encodeURIComponent(nodeDid)}${path}` : path

export function pathFor(route: Route): string {
  if (route.name === 'session')
    return scoped(route.nodeDid, `/sessions/${route.sessionId ?? 'new'}`)
  if (route.name === 'sessions') return scoped(route.nodeDid, '/sessions')
  if (route.name === 'mailbox') return scoped(route.nodeDid, '/mailbox')
  if (route.name === 'agent') {
    const base = `/agents/${encodeURIComponent(route.nodeDid)}/${route.section}`
    return route.item ? `${base}/${route.item}` : base
  }
  return `/${route.name}`
}

export function parseRoute(path: string): Route {
  let parts = path.replace(/^#\/?/, '').replace(/^\//, '').split('/').filter(Boolean)
  /* /nodes/<did>/... scopes what follows to one node; /nodes alone is the list */
  let nodeDid: string | undefined
  if (parts[0] === 'nodes') {
    if (!parts[1]) return { name: 'nodes' }
    nodeDid = decodeURIComponent(parts[1])
    parts = parts.slice(2)
  }
  const withNode = (route: Route): Route =>
    nodeDid && (route.name === 'sessions' || route.name === 'session' || route.name === 'mailbox')
      ? { ...route, nodeDid }
      : route
  if (parts[0] === 'sessions' && parts[1]) {
    return withNode({ name: 'session', sessionId: parts[1] === 'new' ? null : parts[1] })
  }
  if (parts[0] === 'mailbox') return withNode({ name: 'mailbox' })
  if (parts[0] === 'agents' && parts[1]) {
    return {
      name: 'agent',
      nodeDid: decodeURIComponent(parts[1]),
      section: parts[2] ?? 'agent',
      item: parts[3],
    }
  }
  if (parts[0] === 'agents') return { name: 'agents' }
  return withNode({ name: 'sessions' })
}

/* The navigation history as a cursor over a list, the way a browser keeps
   it: navigating from the middle discards what lay ahead, back and forward
   move the cursor, and both say whether they can. Hosts without URLs (the
   desktop) run on this alone; a host with them keeps it as the owner of
   the cursor and mirrors the current route out. */
export type MemoryHistory = {
  readonly route: Route
  readonly canBack: boolean
  readonly canForward: boolean
  navigate: (route: Route) => void
  back: () => void
  forward: () => void
  href: (route: Route) => string
}

export function createMemoryHistory(initial: Route = { name: 'sessions' }): MemoryHistory {
  const entries: Route[] = [initial]
  let index = 0
  return {
    get route() {
      return entries[index]!
    },
    get canBack() {
      return index > 0
    },
    get canForward() {
      return index < entries.length - 1
    },
    navigate(route) {
      entries.splice(index + 1)
      entries.push(route)
      index = entries.length - 1
    },
    back() {
      if (index > 0) index -= 1
    },
    forward() {
      if (index < entries.length - 1) index += 1
    },
    href() {
      return '#'
    },
  }
}

/* A route may name the node it is about. Without one, the shell's selected
   node is implied, as it always was; with one, a link survives a change of
   selection or scope. `nodeDid` is the deployment's identity; core is
   renaming its field from agent_did to node_did (gents #1799), and this is
   the one place the shell spells it. */
export type Route =
  | { name: 'sessions'; nodeDid?: string }
  | { name: 'session'; sessionId: string | null; nodeDid?: string }
  | { name: 'mailbox'; nodeDid?: string }
  | { name: 'nodes' }
  | { name: 'agents' }
  | { name: 'agent'; agentDid: string; section: string; item?: string }

const scoped = (nodeDid: string | undefined, path: string) =>
  nodeDid ? `/nodes/${encodeURIComponent(nodeDid)}${path}` : path

export function pathFor(route: Route): string {
  if (route.name === 'session')
    return scoped(route.nodeDid, `/sessions/${route.sessionId ?? 'new'}`)
  if (route.name === 'sessions') return scoped(route.nodeDid, '/sessions')
  if (route.name === 'mailbox') return scoped(route.nodeDid, '/mailbox')
  if (route.name === 'agent') {
    const base = `/agents/${encodeURIComponent(route.agentDid)}/${route.section}`
    return route.item ? `${base}/${route.item}` : base
  }
  return `/${route.name}`
}

export function parseRoute(path: string): Route {
  let parts = path.replace(/^#\/?/, '').replace(/^\//, '').split('/').filter(Boolean)
  /* /nodes/<did>/... scopes what follows to one node; /nodes alone is the list */
  let nodeDid: string | undefined
  if (parts[0] === 'nodes') {
    if (!parts[1]) return { name: 'nodes' }
    nodeDid = decodeURIComponent(parts[1])
    parts = parts.slice(2)
  }
  const withNode = (route: Route): Route =>
    nodeDid && (route.name === 'sessions' || route.name === 'session' || route.name === 'mailbox')
      ? { ...route, nodeDid }
      : route
  if (parts[0] === 'sessions' && parts[1]) {
    return withNode({ name: 'session', sessionId: parts[1] === 'new' ? null : parts[1] })
  }
  if (parts[0] === 'mailbox') return withNode({ name: 'mailbox' })
  if (parts[0] === 'agents' && parts[1]) {
    return {
      name: 'agent',
      agentDid: decodeURIComponent(parts[1]),
      section: parts[2] ?? 'agent',
      item: parts[3],
    }
  }
  if (parts[0] === 'agents') return { name: 'agents' }
  return withNode({ name: 'sessions' })
}

export type MemoryHistory = {
  readonly route: Route
  navigate: (route: Route) => void
  back: () => void
  href: (route: Route) => string
}

export function createMemoryHistory(initial: Route = { name: 'sessions' }): MemoryHistory {
  const stack: Route[] = [initial]
  return {
    get route() {
      return stack[stack.length - 1]!
    },
    navigate(route) {
      stack.push(route)
    },
    back() {
      if (stack.length > 1) stack.pop()
    },
    href() {
      return '#'
    },
  }
}

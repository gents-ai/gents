export type Route =
  | { name: 'sessions' }
  | { name: 'session'; sessionId: string | null }
  | { name: 'mailbox' }
  | { name: 'agents' }
  | { name: 'agent'; agentDid: string; section: string; item?: string }

export function pathFor(route: Route): string {
  if (route.name === 'session') return `/sessions/${route.sessionId ?? 'new'}`
  if (route.name === 'agent') {
    const base = `/agents/${encodeURIComponent(route.agentDid)}/${route.section}`
    return route.item ? `${base}/${route.item}` : base
  }
  return `/${route.name}`
}

export function parseRoute(path: string): Route {
  const parts = path.replace(/^#\/?/, '').replace(/^\//, '').split('/').filter(Boolean)
  if (parts[0] === 'sessions' && parts[1]) {
    return { name: 'session', sessionId: parts[1] === 'new' ? null : parts[1] }
  }
  if (parts[0] === 'mailbox') return { name: 'mailbox' }
  if (parts[0] === 'agents' && parts[1]) {
    return {
      name: 'agent',
      agentDid: decodeURIComponent(parts[1]),
      section: parts[2] ?? 'agent',
      item: parts[3],
    }
  }
  if (parts[0] === 'agents') return { name: 'agents' }
  return { name: 'sessions' }
}

export type MemoryHistory = {
  readonly route: Route
  navigate: (route: Route) => void
  back: () => void
  href: (route: Route) => string
}

export function createMemoryHistory(initial: Route = { name: 'sessions' }): MemoryHistory {
  const stack: Route[] = [initial]
  return {
    get route() {
      return stack[stack.length - 1]!
    },
    navigate(route) {
      stack.push(route)
    },
    back() {
      if (stack.length > 1) stack.pop()
    },
    href() {
      return '#'
    },
  }
}

/* The kit sizes itself with --viewport-* / --safe-area-* CSS variables
   (packages/tokens/src/viewport.css). Native hosts call this once so iOS
   keyboard and visual-viewport offset write those variables. Desktop
   browsers without visualViewport keep the 100dvh defaults. */

export function bindVisualViewport(el: HTMLElement = document.documentElement): () => void {
  const vv = window.visualViewport
  if (!vv) return () => {}

  const apply = () => {
    el.style.setProperty('--mobile-visual-viewport-top', `${vv.offsetTop}px`)
    el.style.setProperty('--mobile-visual-viewport-left', `${vv.offsetLeft}px`)
    el.style.setProperty('--mobile-visual-viewport-width', `${vv.width}px`)
    el.style.setProperty('--mobile-visual-viewport-height', `${vv.height}px`)
  }
  apply()
  vv.addEventListener('resize', apply)
  vv.addEventListener('scroll', apply)
  return () => {
    vv.removeEventListener('resize', apply)
    vv.removeEventListener('scroll', apply)
  }
}

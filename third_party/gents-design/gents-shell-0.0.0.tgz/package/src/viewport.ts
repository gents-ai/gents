const PROPERTIES = [
  '--mobile-visual-viewport-top',
  '--mobile-visual-viewport-left',
  '--mobile-visual-viewport-width',
  '--mobile-visual-viewport-height',
] as const
const MIN_USEFUL_DIMENSION = 64

/** The frame and portaled overlays share layout-viewport coordinates. Invalid
 * transient keyboard/rotation measurements fall back to the CSS viewport. */
export function bindVisualViewport(
  el: HTMLElement = document.documentElement,
  onResize?: () => void,
): () => void {
  const viewport = window.visualViewport
  if (!viewport) return () => {}

  let width = 0
  let height = 0
  let frame: number | null = null
  const clear = () => {
    for (const property of PROPERTIES) el.style.removeProperty(property)
  }
  const apply = () => {
    frame = null
    if (
      !Number.isFinite(viewport.width) ||
      !Number.isFinite(viewport.height) ||
      viewport.width < MIN_USEFUL_DIMENSION ||
      viewport.height < MIN_USEFUL_DIMENSION
    ) {
      clear()
      return
    }
    const offset = (value: number) => (Number.isFinite(value) ? Math.max(0, value) : 0)
    el.style.setProperty(PROPERTIES[0], `${offset(viewport.offsetTop)}px`)
    el.style.setProperty(PROPERTIES[1], `${offset(viewport.offsetLeft)}px`)
    el.style.setProperty(PROPERTIES[2], `${viewport.width}px`)
    el.style.setProperty(PROPERTIES[3], `${viewport.height}px`)
    if (width !== viewport.width || height !== viewport.height) onResize?.()
    width = viewport.width
    height = viewport.height
  }
  const schedule = () => {
    if (frame === null) frame = requestAnimationFrame(apply)
  }
  apply()
  viewport.addEventListener('resize', schedule)
  viewport.addEventListener('scroll', schedule)
  window.addEventListener('resize', schedule)
  window.addEventListener('pageshow', schedule)
  window.addEventListener('orientationchange', schedule)
  return () => {
    if (frame !== null) cancelAnimationFrame(frame)
    viewport.removeEventListener('resize', schedule)
    viewport.removeEventListener('scroll', schedule)
    window.removeEventListener('resize', schedule)
    window.removeEventListener('pageshow', schedule)
    window.removeEventListener('orientationchange', schedule)
    clear()
  }
}

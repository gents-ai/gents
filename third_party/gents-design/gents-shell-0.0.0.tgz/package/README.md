# `@gents/shell`

URL-free product navigation for Gents hosts.

The kit (`@gents/ui`) is primitives. This package is the route table and
an in-memory history so a Tauri / iOS host never puts `#/sessions` (or
any path) in the webview URL. Hosts wrap screens with their own
`Nav` adapter:

- **Prototype (ui.gents.xyz):** hash adapter, so David can share links.
- **`apps/gents-desktop`:** `createMemoryHistory()` + a back stack.
  iOS swipe calls `back()`. `href()` is `"#"` and clicks `preventDefault`.

```ts
import { createMemoryHistory, pathFor, parseRoute } from '@gents/shell'
import { MemoryNavProvider, Link, useNav } from '@gents/shell'

const history = createMemoryHistory() // starts on { name: 'sessions' }
history.navigate({ name: 'mailbox' })
history.back()
history.href({ name: 'agents' }) // '#'
pathFor({ name: 'session', sessionId: 'abc' }) // '/sessions/abc' — prototype links only

// Native host: wrap the app. iOS back-swipe calls useNav().back().
<MemoryNavProvider>
  <Link to={{ name: 'mailbox' }}>Mailbox</Link>
</MemoryNavProvider>
```

## Viewport

The tokens define `--viewport-height` (default `100dvh`) and
`--safe-area-*` (`env(safe-area-inset-*)`). App chrome uses the
`viewport-frame` utility. On iOS, call once at boot:

```ts
import { bindVisualViewport } from '@gents/shell'
bindVisualViewport()
```

That writes `--mobile-visual-viewport-*` so the keyboard does not cover
the composer. The host does not reimplement this math.

Screens and AppShell are still in `apps/prototype` until they compile
against bridge 7.1; they move here once that alignment lands.
